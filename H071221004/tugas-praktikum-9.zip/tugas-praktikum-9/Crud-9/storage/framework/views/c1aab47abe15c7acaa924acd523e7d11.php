
<?php $__env->startSection('konten'); ?>
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h2 class="text-center fw-bold">Detail Mahasiswa</h2>
    <hr class="border border-dark border-2 opacity-50">
    <center><img src="<?php echo e(url('image/PP.jpeg')); ?>" alt="" style="max-height: 300px; max-width: 300px"></center>
    <hr class="border border-dark border-2 opacity-50">
    <div class="container p-3">
        <table class="table">
            <tbody>
                <tr>
                    <td class="fw-bold">NIM</td>
                    <td>:</td>
                    
                    <td><?php echo e($data->nim); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Nama</td>
                    <td> : </td>
                    
                    <td><?php echo e($data->nama); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Tanggal Lahir</td>
                    <td> : </td>
                    
                    <td><?php echo e(date('d F Y', strtotime($data->tanggal_lahir))); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Alamat</td>
                    <td> : </td>
                    
                    <td><?php echo e($data->alamat); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold">Jurusan</td>
                    <td> : </td>
                    
                    <td><?php echo e($data->jurusan); ?></td>
                </tr>
            </tbody>
        </table>
        <a href="<?php echo e(url('mahasiswa')); ?>" class="btn btn-danger btn-md"><i class="fa-solid fa-arrow-left fa-lg" style="color: #ffffff;"></i></a>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\External\lab semester 3\LAB WEB\Crud-9\Crud-9\resources\views/mahasiswa/details.blade.php ENDPATH**/ ?>