<?php $__env->startSection('konten'); ?>
<div class="jumbotron mt-5">
    <h1 class="display-4">Welcome to CRUD</h1>
    <p class="lead">CRUD adalah Operasi antara database dengan Web yang dimana memungkinkan developer untuk melakukan <br> 
    Operasi Create, Data, Update, dan Delete pada data yang telah dibuat lalu ditampilkan ke halaman Web</p>
    <hr class="my-4">
    <p>Lebih lengkapnya mari melihat isinya</p>
    <a class="btn btn-primary btn-lg" href="/mahasiswa" role="button">Let's Go</a>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\III\Pemrograman Web\Praktikum\Week9\Crud-9\resources\views/welcome.blade.php ENDPATH**/ ?>