<?php if(Session::has('success')): ?>
    <div class="pt-1" id="success">
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="pt-1" id="error">
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($item); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>    
<?php endif; ?>

<script>
    // Tampilkan pesan sukses
    var successMessage = document.getElementById('success');
    if (successMessage) {
        successMessage.style.display = 'block';

        // Sembunyikan pesan sukses setelah 2 detik
        setTimeout(function() {
            successMessage.style.display = 'none';
        }, 2000); // 2000 milidetik = 2 detik
    }

    // Tampilkan pesan kesalahan
    var errorMessage = document.getElementById('error');
    if (errorMessage) {
        errorMessage.style.display = 'block';

        // Sembunyikan pesan kesalahan setelah 2 detik
        setTimeout(function() {
            errorMessage.style.display = 'none';
        }, 2000); // 2000 milidetik = 2 detik
    }
</script><?php /**PATH D:\Kuliah\III\Pemrograman Web\Praktikum\Week9\crud-laravel9-main\resources\views/komponen/pesan.blade.php ENDPATH**/ ?>