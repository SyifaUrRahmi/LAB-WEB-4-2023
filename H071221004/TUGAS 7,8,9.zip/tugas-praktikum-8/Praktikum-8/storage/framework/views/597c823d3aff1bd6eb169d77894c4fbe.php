<!-- Meng-extend layout dari file 'layouts.main'. Ini menggantikan placeholder <?php echo $__env->yieldContent('container'); ?> di layout dengan konten dari halaman ini. -->
 

<!-- Mulai bagian yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
<?php $__env->startSection('container'); ?> 
<!-- Judul halaman untuk menampilkan hasil pencarian produk -->
    <h1>Hasil Pencarian Produk</h1> 
    
    <!-- Memulai daftar tak terurut (unordered list) untuk menampilkan hasil pencarian produk -->
    <ul> 

        <!-- Melakukan loop pada array $products, yang berisi hasil pencarian produk -->
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <!-- Setiap produk akan ditampilkan sebagai item daftar dengan nama produk -->
            <li><?php echo e($product->productName); ?></li> 
            <!-- Selesai loop untuk menampilkan semua produk yang ditemukan -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <!-- Menutup daftar tak terurut -->
    </ul> 

    <!-- Tautan kembali ke beranda dengan tombol berwarna biru (#007BFF) -->
    <a href="/" class="btn btn-primary">Back to home</a> 
    <!-- Menutup bagian konten yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
<?php $__env->stopSection(); ?> 




<!-- tampilkan data produk yang disearch dengan perulangan -->

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\External\lab semester 3\LAB WEB\Praktikum-8\Praktikum-8\resources\views/productlines.blade.php ENDPATH**/ ?>