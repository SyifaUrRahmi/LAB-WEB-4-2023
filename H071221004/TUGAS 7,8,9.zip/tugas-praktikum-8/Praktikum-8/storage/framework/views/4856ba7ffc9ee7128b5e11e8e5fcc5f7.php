
<?php $__env->startSection('container'); ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="mb-5">
            <h3 class="mb-3">
                <h3>Nama Produk : <a
                        href="<?php echo e(route('products.show', $product->productName)); ?>"><?php echo e($product->productName); ?></a></h3>
            </h3>
            <p>ProductLine : <?php echo e($product->productLine); ?></p>
            <p>ProductVendor : <?php echo e($product->productVendor); ?></p>
            <p>QuantityInStock : <?php echo e($product->quantityInStock); ?></p>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kampus\Semester 3\LAB WEB\Praktikum-8\resources\views/products.blade.php ENDPATH**/ ?>