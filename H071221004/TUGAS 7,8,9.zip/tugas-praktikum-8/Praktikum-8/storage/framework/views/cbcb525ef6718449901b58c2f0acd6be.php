<!-- Meng-extend layout dari file 'layouts.main'. Ini menggantikan placeholder <?php echo $__env->yieldContent('container'); ?> di layout dengan konten dari halaman ini. -->
 

<!-- Mulai bagian yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
<?php $__env->startSection('container'); ?> 
<!-- Judul halaman untuk menampilkan informasi produk. Diberi margin atas sebesar 4 unit (mt-4). -->
    <h2 class="mt-4">Informasi Produk</h2> 

    <!-- Paragraf dengan judul "Nama Produk" yang menampilkan nama produk menggunakan variabel $product->productName. Diberi margin atas sebesar 4 unit (mt-4). -->
    <h5 class="mt-4">Nama Produk : <?php echo e($product->productName); ?></h5> 

    <!-- Paragraf yang menampilkan jenis produk (productLine) menggunakan variabel $product->productLine. -->
    <p>Jenis Produk : <?php echo e($product->productLine); ?></p> 

    <!-- Paragraf yang menampilkan skala produk (productScale) menggunakan variabel $product->productScale. -->
    <p>Skala Produk : <?php echo e($product->productScale); ?></p> <

    <!-- Paragraf yang menampilkan penjual produk (productVendor) menggunakan variabel $product->productVendor. -->
    <p>Penjual Produk : <?php echo e($product->productVendor); ?></p> 

    <!-- Paragraf yang menampilkan deskripsi produk (productDescription) menggunakan variabel $product->productDescription. -->
    <p>Deskripsi : <?php echo e($product->productDescription); ?></p> 

    <!-- Paragraf yang menampilkan jumlah produk dalam stok (quantityInStock) menggunakan variabel $product->quantityInStock. -->
    <p>Stok Barang : <?php echo e($product->quantityInStock); ?></p> 

    <!-- Paragraf yang menampilkan harga beli produk (buyPrice) menggunakan variabel $product->buyPrice. -->
    <p>Harga Beli : <?php echo e($product->buyPrice); ?></p> 

    <!-- Paragraf yang menampilkan harga eceran tertinggi produk (MSRP) menggunakan variabel $product->MSRP. -->
    <p>Harga Eceran Tertinggi : <?php echo e($product->MSRP); ?></p> 

    <!-- Tautan kembali ke halaman produk dengan tombol berwarna biru (#007BFF). -->
    <a href="/product" class="btn btn-primary">Back to products</a> 
<!-- Menutup bagian konten yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
<?php $__env->stopSection(); ?> 


<!-- tampilkan informasi per produk -->
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\External\lab semester 3\LAB WEB\Praktikum-8\Praktikum-8\resources\views/show.blade.php ENDPATH**/ ?>