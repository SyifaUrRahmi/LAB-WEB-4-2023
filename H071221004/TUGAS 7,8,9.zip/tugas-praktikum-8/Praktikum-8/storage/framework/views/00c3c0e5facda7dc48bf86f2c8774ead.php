
<?php $__env->startSection('container'); ?>
    <h2 class="mt-4">Informasi Produk</h2>
    <h5 class="mt-4">Nama Produk : <?php echo e($product->productName); ?></h5>
    <p>Jenis Produk : <?php echo e($product->productLine); ?></p>
    <p>Skala Produk : <?php echo e($product->productScale); ?></p>
    <p>Penjual Produk : <?php echo e($product->productVendor); ?></p>
    <p>Deskripsi : <?php echo e($product->productDescription); ?></p>
    <p>Stok Barang : <?php echo e($product->quantityInStock); ?></p>
    <p>Harga Beli : <?php echo e($product->buyPrice); ?></p>
    <p>Harga Eceran Tertinggi : <?php echo e($product->MSRP); ?></p>
    <a href="/product" class="btn btn-primary">Back to products</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kampus\Semester 3\LAB WEB\Praktikum-8\resources\views/show.blade.php ENDPATH**/ ?>