<!-- Meng-extend layout dari file 'layouts.main'. Ini menggantikan placeholder <?php echo $__env->yieldContent('container'); ?> di layout dengan konten dari halaman ini. -->
 

<!-- Mulai bagian yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
<?php $__env->startSection('container'); ?> 
<!-- Memulai loop untuk setiap produk dalam array $products -->
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <!-- Membuat artikel dengan margin bawah sebesar 5 unit untuk setiap produk -->
        <article class="mb-5"> 
            <h3 class="mb-3">
                <!-- Judul artikel berisi nama produk sebagai tautan ke halaman detail produk menggunakan route 'products.show' -->
                <h3>Nama Produk : <a href="<?php echo e(route('products.show', $product->productName)); ?>"><?php echo e($product->productName); ?></a></h3> 
            </h3>
            <!-- Paragraf yang menampilkan jenis produk (productLine) -->
            <p>ProductLine : <?php echo e($product->productLine); ?></p> 
            <p>ProductVendor : <?php echo e($product->productVendor); ?></p> 
            <!-- Paragraf yang menampilkan jumlah produk dalam stok (quantityInStock) -->
            <!-- Paragraf yang menampilkan vendor produk (productVendor) -->
            <p>QuantityInStock : <?php echo e($product->quantityInStock); ?></p> 
        </article>
        <!-- Selesai loop untuk menampilkan semua produk dalam array $products -->
    <!-- Akhir dari konten yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<!-- Menutup bagian konten yang akan diisi pada placeholder <?php echo $__env->yieldContent('container'); ?> di file layout -->
<?php $__env->stopSection(); ?> 


<!-- tampilkan product -->

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\External\lab semester 3\LAB WEB\Praktikum-8\Praktikum-8\resources\views/products.blade.php ENDPATH**/ ?>