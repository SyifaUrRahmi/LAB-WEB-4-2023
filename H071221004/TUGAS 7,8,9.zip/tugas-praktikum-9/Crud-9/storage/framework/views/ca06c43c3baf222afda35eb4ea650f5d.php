<nav class="navbar navbar-expand-lg" style="background-color: #DF585A">
    <div class="container">
        <a class="navbar-brand"  style="font-weight: 1000" href="/"><i class="fa-solid fa-school fa-xl" style="color: #000000;"></i></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <!-- Menu Utama -->
                <li class="nav-item">
                    <a class="nav-link active" href="/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  active" href="/mahasiswa">Data</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  active" href="/mahasiswa/create">Create</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Kuliah\III\Pemrograman Web\Praktikum\Week9\crud-laravel9-main\resources\views/mahasiswa/partials/navbar.blade.php ENDPATH**/ ?>