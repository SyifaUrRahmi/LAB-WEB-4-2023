# Tutorial CRUD dengan menggunakan Laravel 9 & Bootstrap

Link video bisa diakses melalui YouTube: https://youtu.be/3CbGQEO_d0M

Semoga bermanfaat
